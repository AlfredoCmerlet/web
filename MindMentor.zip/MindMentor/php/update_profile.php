<?php
session_start();
include 'config.php';

if (!isset($_SESSION['unique_id'])) {
    header("Location: Singup-login.php");
    exit();
}

$unique_id = $_SESSION['unique_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_new_password = $_POST['confirm_new_password'];

    // Validar y sanitizar los datos del formulario
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Comprobar la contraseña actual
        $stmt = $conn->prepare("SELECT password FROM users WHERE unique_id = ?");
        $stmt->bind_param("s", $unique_id);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($hashed_password);
        $stmt->fetch();

        if (password_verify($current_password, $hashed_password)) {
            // Si se proporcionó una nueva contraseña, validar y actualizarla
            if (!empty($new_password) && $new_password === $confirm_new_password) {
                $new_hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

                $stmt = $conn->prepare("UPDATE users SET fname = ?, lname = ?, email = ?  WHERE unique_id = ?");
                $stmt->bind_param("ssss", $fname, $lname, $email, $unique_id);
            } else {
                // Si no se proporcionó una nueva contraseña, solo actualizar otros datos
                $stmt = $conn->prepare("UPDATE users SET fname = ?, lname = ?, email = ?  WHERE unique_id = ?");
                $stmt->bind_param("ssss", $fname, $lname, $email, $unique_id);
            }

            if ($stmt->execute()) {
                echo " ";
            } else {
                echo "Error al actualizar el perfil: " . $conn->error;
            }

            $stmt->close();
        } else {
            echo "Contraseña actual incorrecta.";
        }
    } else {
        echo "Correo electrónico no válido.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="icon" type="image/x-icon" href="assets/img/logo.png"/>
   <script src="https://kit.fontawesome.com/af6e45cdde.js"></script>
   <link rel="stylesheet" href="../assets/css/success.css">
   <title>successfully changes</title>
</head>
<body>
   <div class="modal-box">
        <i class="fa-regular fa-circle-check"></i>
        <h2>Successful changes</h2>
        <h3>You have successfully edited your profile.</h3>

        <div class="button">
         <button onclick="window.location.href='../workspace.php'">OK, that's all.</button>
        </div>
    </div>
</body>
</html>