<?php
// connection.php: asegúrate de que la conexión a la base de datos sea correcta
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['file'])) {
    // Directorio donde se guardará el archivo
    $target_dir = "uploads/";
    // Nombre del archivo con el path completo
    $target_file = $target_dir . basename($_FILES["file"]["name"]);
    // Variable para verificar si el archivo es válido
    $uploadOk = 1;
    $fileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Comprobar si el archivo ya existe
    if (file_exists($target_file)) {
        echo "Sorry, file already exists.";
        $uploadOk = 0;
    }

    // Permitir ciertos formatos de archivo
    if ($fileType != "jpg" && $fileType != "png" && $fileType != "jpeg" && $fileType != "gif" ) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    // Verificar si $uploadOk es 0 por un error
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    // Si todo está bien, intentar subir el archivo
    } else {
        if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
            echo "The file ". htmlspecialchars(basename($_FILES["file"]["name"])) . " has been uploaded.";

            // Guardar la información del archivo en la base de datos
            $stmt = $conn->prepare("INSERT INTO files (filename, filepath) VALUES (?, ?)");
            $stmt->bind_param("ss", $_FILES["file"]["name"], $target_file);
            
            if ($stmt->execute()) {
                echo "File info saved to database.";
            } else {
                echo "Error saving file info to database: " . $stmt->error;
            }
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
} else {
    echo "No file uploaded.";
}
?>
