<?php
// login.php
session_start();
include 'config.php'; // Asegúrate de que la ruta es correcta y el archivo existe

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['email']) && isset($_POST['password'])) {
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $password = mysqli_real_escape_string($conn, $_POST['password']);

        if (!empty($email) && !empty($password)) {
            $sql = mysqli_query($conn, "SELECT * FROM users WHERE email = '{$email}'");
            if (mysqli_num_rows($sql) > 0) {
                $row = mysqli_fetch_assoc($sql);
                $enc_pass = $row['password'];

                if (password_verify($password, $enc_pass)) {
                    $status = "Active now";
                    $sql2 = mysqli_query($conn, "UPDATE users SET status = '{$status}' WHERE unique_id = {$row['unique_id']}");
                    if ($sql2) {
                        $_SESSION['user_name'] = $row['first_name'];
                        $_SESSION['unique_id'] = $row['unique_id'];
                        $_SESSION['img'] = $row['img']; // Añadir imagen a la sesión

                        header("Location: ../workspace.php");
                        exit();
                    } else {
                        echo "Something went wrong. Please try again!";
                    }
                } else {
                    echo "Email or Password is Incorrect!";
                }
            } else {
                echo "$email - This email does not exist!";
            }
        } else {
            echo "All input fields are required!";
        }
    } else {
        echo "Please fill out all form fields.";
    }
}
$conn->close();
?>
