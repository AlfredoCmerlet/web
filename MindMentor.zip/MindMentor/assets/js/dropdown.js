let profileDropdownList = document.querySelector(".profile-dropdown-list");
let btn = document.querySelector(".user-button");

const toggle = ()=> profileDropdownList.classList.toggle('active');

window.addEventListener("click", function(e){
   if(!btn.contains(e.target)) profileDropdownList.classList.remove("active")
});
