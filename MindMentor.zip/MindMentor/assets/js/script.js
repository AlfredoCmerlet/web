document.getElementById("btn_Log-in").addEventListener("click", login);
document.getElementById("btn_register").addEventListener("click", register);
window.addEventListener("resize", widthPage)

//Declaración de variables
var containerLoginRegister = document.querySelector(".container_Login-Register");
var formLogin = document.querySelector(".Login-form");
var formRegister = document.querySelector(".register-form");
var backgroundLogin = document.querySelector(".background_box-login");
var backgroundRegister = document.querySelector(".background_box-register");

function widthPage () {
   if(window.innerWidth > 850){
      backgroundLogin.style.display = "block";
      backgroundRegister.style.display = "block";
   }else{
      backgroundRegister.style.display = "block";
      backgroundRegister.style.opacity = "1";
      backgroundLogin.style.display = "none";
      formLogin.style.display = "block";
      formRegister.style.display = "none";
      containerLoginRegister.style.left = "0"
   }
}

widthPage();

function login () {

   if(window.innerWidth > 850){
      formRegister.style.display = "none";
      containerLoginRegister.style.left = "10px";
      formLogin.style.display = "block";
      backgroundRegister.style.opacity = "1";
      backgroundLogin.style.opacity = "0";
   }else{
      formRegister.style.display = "none";
      containerLoginRegister.style.left = "0px";
      formLogin.style.display = "block";
      backgroundRegister.style.display = "block";
      backgroundLogin.style.display = "none";
   }
}


function register () {

   if(window.innerWidth > 850){
      formRegister.style.display = "block";
      containerLoginRegister.style.left = "410px";
      formLogin.style.display = "none";
      backgroundRegister.style.opacity = "0";
      backgroundLogin.style.opacity = "1";
   }else{
      formRegister.style.display = "block";
      containerLoginRegister.style.left = "0px";
      formLogin.style.display = "none";
      backgroundRegister.style.display = "none";
      backgroundLogin.style.display = "block";
      backgroundLogin.style.opacity = "1";
   }
}
