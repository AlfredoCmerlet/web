document.addEventListener("DOMContentLoaded", function() {
    const profileImageContainer = document.querySelector(".profile-img-container");
    const profileImageInput = document.querySelector("#profileImageInput");
  
    profileImageContainer.addEventListener("click", function() {
        profileImageInput.click();
    });
  
    profileImageInput.addEventListener("change", function() {
        // Aquí puedes añadir una vista previa de la imagen cargada si lo deseas
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                document.querySelector(".profile-img").src = e.target.result;
            }
            reader.readAsDataURL(file);
        }
    });
  });